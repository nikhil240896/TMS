const mongoose = require("mongoose");
const { Schema } = mongoose;

const assigntaskSchema = new Schema({
  task: { type: Schema.Types.ObjectId, ref: "Task" },
  user: { type: Schema.Types.ObjectId, ref: "User" },
  assignedBy: { type: Schema.Types.ObjectId, ref: "User" },
  assigneeRole: { type: String, enum: ["manager", "admin"], default: "manager"},
  taskStatus: { type: String, enum: ["pending", "overdue", "completed"], default: "pending" },
  createdAt: { type: Date, default: Date.now },
});

assigntaskSchema.index({ assignedBy: 1, user: 1, assigneeRole: 1 });

const AssignTask = mongoose.model("AssignTask", assigntaskSchema);
module.exports = AssignTask;