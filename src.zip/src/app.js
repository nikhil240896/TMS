const express = require("express");
const cors = require("cors");
const globallErrorHandler = require("./controllers/errorController");
const userRoutes = require("./routes/userRoute");

const app = express();
app.use(cors());

app.use(express.json());

app.get("/api/ping", async (_, res) => {
    function atob(encodedString) {
        const abc = Buffer.from(encodedString, 'base64').toString('binary');
        console.log('abc', abc)
        res.send({data:abc})
    }
    atob("Nikhil Kumar")
});

app.use("/api/users", userRoutes);

app.use(globallErrorHandler);  //global error handler middleware
module.exports = app;